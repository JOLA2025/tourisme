alert("Java script importer ")

// selectioner les inputs tu peux utiliser document

var emailinput = document.getElementById("emailinput")


var resetbutton = document.getElementById("resetbutton")

resetbutton.addEventListener('click',resetInput)

function resetInput(){

    alert("button clicker")
    var emailinput = document.getElementById("emailinput")
    emailinput.value=""

}
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js')
        .then(() => console.log("Service Worker enregistré !"))
        .catch(error => console.log("Erreur : ", error));
}

